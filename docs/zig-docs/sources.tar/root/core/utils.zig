//! # Utility Module

const std = @import("std");
const Io = std.Io;
const log = std.log;
const linux = std.os.linux;
const SrcLoc = std.builtin.SourceLocation;

const DateTime = @import("./datetime.zig");

const Str = []const u8;

/// # Logs Syscall Error Number
/// - e.g., Bad file descriptor (EBADF) - `utils.syscallError(9, @src());`
pub fn syscallError(code: i32, src: SrcLoc) void {
    const err: linux.E = @enumFromInt(@as(u16, @truncate(@abs(code))));
    const fmt_str = "Syscall - Errno {d} E{s} occurred in {s} at line {d}";
    log.err(fmt_str, .{code, @tagName(err), src.file, src.line});
}

/// # Out of Memory Error
/// **Remarks:** Exhausting memory means that all bets are off. Handling
/// fallible memory allocations often leads to code complexity and sometimes
/// not worth the effort. However, be cautious about the potential data lose!
pub fn oom(io: Io, src: SrcLoc) noreturn {
    const datetime = DateTime.now(io).toLocal(.BST);
    const fmt_str = "{s} [FATAL] {s} at {d}:{d}\n";
    log.info(fmt_str, .{datetime, src.file, src.line, src.column});
    log.err("~ Out Of Memory", .{});
    std.process.exit(255);
}

/// # App Abruptly Exits
///
/// **Remarks:** `@panic()` and `std.debug.panic()` has inconstancy.
/// Process doesn't exit completely when calling from detached threads.
pub fn panic(io: Io, comptime format: Str, arg: anytype, src: SrcLoc) noreturn {
    const datetime = DateTime.now(io).toLocal(.BST);
    const fmt_str = "{s} [FATAL] {s} at {d}:{d}\n";
    log.info(fmt_str, .{datetime, src.file, src.line, src.column});
    log.err(format, arg);
    std.process.exit(254);
}

/// # Unrecoverable Error Handle
/// **Remarks:** Prevents unnecessary code repetition when needed multiple times
pub fn unrecoverable(io: Io, err: anyerror, src: SrcLoc) noreturn {
    panic(io, "~ {s}", .{@errorName(err)}, src);
}
